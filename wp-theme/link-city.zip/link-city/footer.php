<?php if (!is_front_page()) { ?>
<!-- load intro -->
<div class="load_intro">
    <div class="wrap">
        <div class="may left">
            <img data-skip-lazy="" src="<?php echo get_template_directory_uri(); ?>/assets/images/left_la.png" alt="" />
        </div>
        <div class="may right">
            <img data-skip-lazy="" src="<?php echo get_template_directory_uri(); ?>/assets/images/right_la.png" alt="" />
        </div>
    </div>
</div>
<?php } ?>

<!-- First modal -->
<div class="modal-container" id="lepopup-form-13">
    <div class="modal-content lepopup-form-inner">
        <div class="lepopup-element lepopup-element-2">
            <form class="lepopup-form" id="lepopup-contact-form">
                <h2 class="lepopup-element-title" data-aos="fade-up" data-aos-duration="700">
                    ĐĂNG KÝ TÌM HIỂU <br />
                    THÔNG TIN DỰ ÁN
                </h2>

                <div class="lepopup-element-description" data-aos="fade-up" data-aos-duration="700">
                    Vui lòng để lại thông tin, nhân viên chúng tôi <br />
                    sẽ liên hệ lại với Quý khách sớm nhất có thể.
                </div>

                <div class="flex-box" style="gap: 15px; margin-top: 20px" data-aos="fade-up" data-aos-duration="800">
                    <div class="lepopup-input">
                        <input type="text" name="lepopup_name" class="lepopup-ta-left" placeholder="Tên của bạn" autocomplete="off" value="" aria-label="Name Field" required />
                    </div>
                    <div class="lepopup-input">
                        <input type="tel" name="lepopup_phone" class="lepopup-ta-left" placeholder="Số điện thoại" autocomplete="tel" value="" aria-label="Phone Field" required />
                    </div>
                </div>

                <div class="lepopup-input" style="margin-top: 15px" data-aos="fade-up" data-aos-duration="900">
                    <input type="email" name="lepopup_email" class="lepopup-ta-left" placeholder="Email của bạn" autocomplete="email" value="" aria-label="E-mail Field" required />
                </div>

                <!-- Hidden fields for form processing -->
                <input type="hidden" name="lepopup_form_submit" value="yes" />
                <input type="hidden" name="lepopup_nonce" value="<?php echo wp_create_nonce('lepopup_form_nonce'); ?>" />

                <div class="lepopup-button-wrapper" data-aos="fade-up" data-aos-duration="1000">
                    <button type="submit" class="lepopup-button lepopup-button-zoom-out">GỬI THÔNG TIN</button>
                </div>

                <div class="lepopup-close">
                    <span>×</span>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- // load home page  -->
<div class="load_home_page">
    <div class="mask"> <span></span><span></span><span></span><span></span><span></span> </div>
    <svg xmlns="http://www.w3.org/2000/svg" width="172" height="35" viewBox="0 0 172 35" fill="none">
        <path class="path-2" d="M142.283 23.9659H143.493L145.913 28.0398H146.016L148.436 23.9659H149.646L146.493 29.0966V32.6932H145.436V29.0966L142.283 23.9659Z" fill="#F36B24" />
        <path class="path-2" d="M136.172 32.6932H135.064L138.268 23.9659H139.359L142.564 32.6932H141.456L138.848 25.3466H138.78L136.172 32.6932ZM136.581 29.2841H141.047V30.2216H136.581V29.2841ZM139.7 23.1818L138.814 21.9886L137.928 23.1818H136.973V23.1136L138.354 21.3409H139.274L140.655 23.1136V23.1818H139.7Z" fill="#F36B24" />
        <path class="path-2" d="M133.695 23.9659V32.6932H132.638V23.9659H133.695Z" fill="#F36B24" />
        <path class="path-2" d="M129.686 26.6932C129.592 26.4062 129.469 26.1491 129.315 25.9219C129.165 25.6918 128.984 25.4957 128.774 25.3338C128.567 25.1719 128.331 25.0483 128.067 24.9631C127.803 24.8778 127.513 24.8352 127.197 24.8352C126.68 24.8352 126.21 24.9687 125.787 25.2358C125.364 25.5028 125.027 25.8963 124.777 26.4162C124.527 26.9361 124.402 27.5739 124.402 28.3295C124.402 29.0852 124.528 29.723 124.781 30.2429C125.034 30.7628 125.376 31.1562 125.808 31.4233C126.24 31.6903 126.726 31.8239 127.266 31.8239C127.766 31.8239 128.206 31.7173 128.587 31.5043C128.97 31.2884 129.268 30.9844 129.482 30.5923C129.697 30.1974 129.805 29.733 129.805 29.1989L130.129 29.267H127.504V28.3295H130.828V29.267C130.828 29.9858 130.675 30.6108 130.368 31.142C130.064 31.6733 129.643 32.0852 129.107 32.3778C128.572 32.6676 127.959 32.8125 127.266 32.8125C126.493 32.8125 125.814 32.6307 125.229 32.267C124.646 31.9034 124.192 31.3864 123.865 30.7159C123.541 30.0455 123.379 29.25 123.379 28.3295C123.379 27.6392 123.472 27.0185 123.656 26.4673C123.844 25.9134 124.108 25.4418 124.449 25.0526C124.79 24.6634 125.193 24.3651 125.659 24.1577C126.125 23.9503 126.638 23.8466 127.197 23.8466C127.658 23.8466 128.087 23.9162 128.484 24.0554C128.885 24.1918 129.241 24.3864 129.554 24.6392C129.869 24.8892 130.132 25.1889 130.342 25.5384C130.553 25.8849 130.697 26.2699 130.777 26.6932H129.686Z" fill="#F36B24" />
        <path class="path-2" d="M117.178 23.9659H118.235V29.7443C118.235 30.3409 118.094 30.8736 117.813 31.3423C117.534 31.8082 117.141 32.1761 116.632 32.446C116.124 32.7131 115.527 32.8466 114.843 32.8466C114.158 32.8466 113.561 32.7131 113.053 32.446C112.544 32.1761 112.15 31.8082 111.868 31.3423C111.59 30.8736 111.451 30.3409 111.451 29.7443V23.9659H112.507V29.6591C112.507 30.0852 112.601 30.4645 112.789 30.7969C112.976 31.1264 113.243 31.3864 113.59 31.5767C113.939 31.7642 114.357 31.858 114.843 31.858C115.328 31.858 115.746 31.7642 116.096 31.5767C116.445 31.3864 116.712 31.1264 116.897 30.7969C117.084 30.4645 117.178 30.0852 117.178 29.6591V23.9659Z" fill="#F36B24" />
        <path class="path-2" d="M103.699 32.6932H102.591L105.796 23.9659H106.887L110.091 32.6932H108.983L106.375 25.3466H106.307L103.699 32.6932ZM104.108 29.2841H108.574V30.2216H104.108V29.2841ZM106.801 21.6136L108.54 23.1648H107.313L106.341 22.2614L105.37 23.1648H104.142L105.864 21.6136H106.801ZM103.767 20.5739L104.586 22.125H103.716L102.506 20.5739H103.767Z" fill="#F36B24" />
        <path class="path-2" d="M97.8196 32.6932H95.1264V23.9659H97.9389C98.7855 23.9659 99.5099 24.1406 100.112 24.4901C100.714 24.8366 101.176 25.3352 101.497 25.9858C101.818 26.6335 101.979 27.4091 101.979 28.3125C101.979 29.2216 101.817 30.0043 101.493 30.6605C101.169 31.3139 100.697 31.8168 100.078 32.169C99.4588 32.5185 98.706 32.6932 97.8196 32.6932ZM96.1832 31.7557H97.7514C98.473 31.7557 99.071 31.6165 99.5455 31.3381C100.02 31.0597 100.374 30.6634 100.607 30.1492C100.839 29.6349 100.956 29.0227 100.956 28.3125C100.956 27.608 100.841 27.0014 100.611 26.4929C100.381 25.9815 100.037 25.5895 99.5795 25.3168C99.1222 25.0412 98.5526 24.9034 97.8707 24.9034H96.1832V31.7557Z" fill="#F36B24" />
        <path class="path-2" d="M89.6325 23.9659V32.6932H88.5756V23.9659H89.6325ZM89.104 34.858C88.908 34.858 88.739 34.7912 88.5969 34.6577C88.4577 34.5242 88.3881 34.3636 88.3881 34.1761C88.3881 33.9886 88.4577 33.8281 88.5969 33.6946C88.739 33.5611 88.908 33.4943 89.104 33.4943C89.3001 33.4943 89.4677 33.5611 89.6069 33.6946C89.7489 33.8281 89.82 33.9886 89.82 34.1761C89.82 34.3636 89.7489 34.5242 89.6069 34.6577C89.4677 34.7912 89.3001 34.858 89.104 34.858Z" fill="#F36B24" />
        <path class="path-2" d="M79.6928 32.6932V23.9659H80.7496V27.8523H85.4031V23.9659H86.4599V32.6932H85.4031V28.7898H80.7496V32.6932H79.6928Z" fill="#F36B24" />
        <path class="path-2" d="M71.5163 24.9034V23.9659H78.0618V24.9034H75.3175V32.6932H74.2606V24.9034H71.5163Z" fill="#F36B24" />
        <path class="path-2" d="M66.8416 28.3295C66.8416 29.25 66.6754 30.0455 66.343 30.7159C66.0107 31.3864 65.5547 31.9034 64.9751 32.267C64.3956 32.6307 63.7337 32.8125 62.9893 32.8125C62.245 32.8125 61.5831 32.6307 61.0035 32.267C60.424 31.9034 59.968 31.3864 59.6357 30.7159C59.3033 30.0455 59.1371 29.25 59.1371 28.3295C59.1371 27.4091 59.3033 26.6136 59.6357 25.9432C59.968 25.2727 60.424 24.7557 61.0035 24.392C61.5831 24.0284 62.245 23.8466 62.9893 23.8466C63.7337 23.8466 64.3956 24.0284 64.9751 24.392C65.5547 24.7557 66.0107 25.2727 66.343 25.9432C66.6754 26.6136 66.8416 27.4091 66.8416 28.3295ZM65.8189 28.3295C65.8189 27.5739 65.6925 26.9361 65.4396 26.4162C65.1896 25.8963 64.8501 25.5028 64.4212 25.2358C63.995 24.9688 63.5178 24.8352 62.9893 24.8352C62.4609 24.8352 61.9822 24.9688 61.5533 25.2358C61.1271 25.5028 60.7876 25.8963 60.5348 26.4162C60.2848 26.9361 60.1598 27.5739 60.1598 28.3295C60.1598 29.0852 60.2848 29.723 60.5348 30.2429C60.7876 30.7628 61.1271 31.1563 61.5533 31.4233C61.9822 31.6903 62.4609 31.8239 62.9893 31.8239C63.5178 31.8239 63.995 31.6903 64.4212 31.4233C64.8501 31.1563 65.1896 30.7628 65.4396 30.2429C65.6925 29.723 65.8189 29.0852 65.8189 28.3295ZM63.8757 23.1818L62.9893 21.9886L62.103 23.1818H61.1484V23.1136L62.5291 21.3409H63.4496L64.8302 23.1136V23.1818H63.8757Z" fill="#F36B24" />
        <path class="path-2" d="M53.5462 32.6932H51.4496V31.7557H53.478C54.1996 31.7557 54.7976 31.6165 55.272 31.3381C55.7465 31.0597 56.1001 30.6634 56.3331 30.1492C56.5661 29.6349 56.6825 29.0227 56.6825 28.3125C56.6825 27.608 56.5675 27.0014 56.3374 26.4929C56.1072 25.9815 55.7635 25.5895 55.3061 25.3168C54.8487 25.0412 54.2791 24.9034 53.5973 24.9034H51.3984V23.9659H53.6655C54.5121 23.9659 55.2365 24.1406 55.8388 24.4901C56.4411 24.8366 56.9027 25.3352 57.2237 25.9858C57.5447 26.6335 57.7053 27.4091 57.7053 28.3125C57.7053 29.2216 57.5433 30.0043 57.2195 30.6605C56.8956 31.3139 56.424 31.8168 55.8047 32.169C55.1854 32.5185 54.4325 32.6932 53.5462 32.6932ZM51.9098 23.9659V32.6932H50.853V23.9659H51.9098ZM49.5064 28.5852V27.8011H53.2564V28.5852H49.5064Z" fill="#F36B24" />
        <path class="path-2" d="M44.3107 23.9659H45.3675V29.7443C45.3675 30.3409 45.2269 30.8736 44.9457 31.3423C44.6673 31.8082 44.2738 32.1761 43.7653 32.446C43.2567 32.7131 42.6602 32.8466 41.9755 32.8466C41.2908 32.8466 40.6942 32.7131 40.1857 32.446C39.6772 32.1761 39.2823 31.8082 39.0011 31.3423C38.7227 30.8736 38.5835 30.3409 38.5835 29.7443V23.9659H39.6403V29.6591C39.6403 30.0852 39.734 30.4645 39.9215 30.7969C40.109 31.1264 40.3761 31.3864 40.7227 31.5767C41.0721 31.7642 41.4897 31.858 41.9755 31.858C42.4613 31.858 42.8789 31.7642 43.2283 31.5767C43.5778 31.3864 43.8448 31.1264 44.0295 30.7969C44.217 30.4645 44.3107 30.0852 44.3107 29.6591V23.9659Z" fill="#F36B24" />
        <path class="path-2" d="M29.7006 32.6932V23.9659H30.7575V27.8523H35.4109V23.9659H36.4677V32.6932H35.4109V28.7898H30.7575V32.6932H29.7006Z" fill="#F36B24" />
        <path class="path-2" d="M21.8725 32.6932V23.9659H22.9293V28.2955H23.0316L26.9521 23.9659H28.3327L24.668 27.9034L28.3327 32.6932H27.0543L24.0202 28.6364L22.9293 29.8636V32.6932H21.8725Z" fill="#F36B24" />
        <path class="path-1" d="M154.728 0.238617H158.862L162.842 7.75566H163.012L166.992 0.238617H171.126L164.759 11.5227V17.6932H161.094V11.5227L154.728 0.238617Z" fill="white" />
        <path class="path-1" d="M139.055 3.28123V0.238617H153.39V3.28123H148.046V17.6932H144.398V3.28123H139.055Z" fill="white" />
        <path class="path-1" d="M136.683 0.238617V17.6932H132.993V0.238617H136.683Z" fill="white" />
        <path class="path-1" d="M130.347 6.34943H126.614C126.545 5.86648 126.406 5.4375 126.196 5.0625C125.986 4.68182 125.716 4.35795 125.386 4.09091C125.057 3.82386 124.676 3.61932 124.244 3.47727C123.818 3.33523 123.355 3.26421 122.855 3.26421C121.952 3.26421 121.165 3.48864 120.494 3.9375C119.824 4.38068 119.304 5.02841 118.935 5.88068C118.565 6.72727 118.381 7.75568 118.381 8.96591C118.381 10.2102 118.565 11.2557 118.935 12.1023C119.31 12.9489 119.832 13.5881 120.503 14.0199C121.173 14.4517 121.949 14.6676 122.83 14.6676C123.324 14.6676 123.781 14.6023 124.202 14.4716C124.628 14.3409 125.006 14.1506 125.335 13.9006C125.665 13.6449 125.938 13.3352 126.153 12.9716C126.375 12.608 126.528 12.1932 126.614 11.7273L130.347 11.7443C130.25 12.5455 130.009 13.3182 129.622 14.0625C129.241 14.8011 128.727 15.4631 128.08 16.0483C127.438 16.6278 126.67 17.0881 125.778 17.429C124.892 17.7642 123.889 17.9318 122.77 17.9318C121.213 17.9318 119.821 17.5795 118.594 16.875C117.372 16.1705 116.406 15.1506 115.696 13.8153C114.991 12.4801 114.639 10.8636 114.639 8.96591C114.639 7.0625 114.997 5.44318 115.713 4.10796C116.429 2.77273 117.401 1.75568 118.628 1.05682C119.855 0.352273 121.236 0 122.77 0C123.781 0 124.719 0.142045 125.582 0.426136C126.452 0.710227 127.222 1.125 127.892 1.67045C128.563 2.21023 129.108 2.87216 129.528 3.65625C129.955 4.44034 130.227 5.33807 130.347 6.34943Z" fill="white" />
        <path class="path-1" d="M92.8445 17.6932V0.238617H96.5348V7.93464H96.7649L103.046 0.238617H107.469L100.992 8.05396L107.546 17.6932H103.131L98.3501 10.517L96.5348 12.7329V17.6932H92.8445Z" fill="white" />
        <path class="path-1" d="M89.7954 0.238617V17.6932H86.6079L79.0142 6.70737H78.8864V17.6932H75.196V0.238617H78.4347L85.9687 11.2159H86.1222V0.238617H89.7954Z" fill="white" />
        <path class="path-1" d="M72.1598 0.238617V17.6932H68.4695V0.238617H72.1598Z" fill="white" />
        <path class="path-1" d="M54.8523 17.6932V0.238617H58.5426V14.6505H66.0256V17.6932H54.8523Z" fill="white" />
        <path class="path-1" d="M34.6023 17.6932V0.238617H46.3636V3.28123H38.2926V7.44032H45.7585V10.4829H38.2926V14.6505H46.3977V17.6932H34.6023Z" fill="white" />
        <path class="path-1" d="M16.696 17.6932V0.238617H20.3864V7.44032H27.8778V0.238617H31.5597V17.6932H27.8778V10.4829H20.3864V17.6932H16.696Z" fill="white" />
        <path class="path-1" d="M0 3.28123V0.238617H14.3352V3.28123H8.99148V17.6932H5.34375V3.28123H0Z" fill="white" />
        <path d="M3.88602 28.6932H18.116" stroke="#F26522" stroke-miterlimit="10" />
        <path d="M154.886 28.6932H169.116" stroke="#F26522" stroke-miterlimit="10" />
    </svg>
    <script>
        setTimeout(() => {
            jQuery(".load_home_page").addClass("complete");
            setTimeout(() => {
                jQuery("body").removeClass("unscrollable");
            }, 800);
        }, 1000);
    </script>
</div>

<div class="modal-container" id="search-lightbox">
    <div class="modal-content">
        <div class="search-lightbox-title">Chúng tôi có thể giúp bạn tìm kiếm?</div>
        <div class="searchform-wrapper ux-search-box relative is-large">
            <form method="get" class="searchform" action="<?php echo home_url(); ?>" role="search">
                <div class="flex-row relative">
                    <div class="input-container">
                        <input class="search-field mb-0" name="s" value="" id="s" placeholder="Tìm kiếm" />
                    </div>
                    <div class="icon-search">
                        <button type="submit" class="ux-search-submit submit-button secondary button icon mb-0" aria-label="Nộp">
                            <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.1406 22.6565C18.396 22.6565 22.6562 18.3962 22.6562 13.1409C22.6562 7.88553 18.396 3.62524 13.1406 3.62524C7.88529 3.62524 3.625 7.88553 3.625 13.1409C3.625 18.3962 7.88529 22.6565 13.1406 22.6565Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M19.8687 19.8698L25.3742 25.3753" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="live-search-results text-left z-top"></div>
            </form>
        </div>
        <div class="search-keywords">
            <a href="<?php echo home_url(); ?>/?s=The Link City">The Link City</a>
            <a href="<?php echo home_url(); ?>/?s=Tiện ích">Tiện ích</a>
            <a href="<?php echo home_url(); ?>/?s=Hình ảnh dự án">Hình ảnh dự án</a>
            <a href="<?php echo home_url(); ?>/?s=Tiến độ">Tiến độ</a>
            <a href="<?php echo home_url(); ?>/?s=Legacy Central">Legacy Central</a>
        </div>
    </div>
</div>

<!-- ============================ START FIXED BUTTONS ============================ -->
<div class="fixed-buttons">
    <div class="item">
        <div class="item-inner">
            <a href="tel:<?php echo get_theme_mod('phone_number', '0922222256'); ?>" title="Hotline">
                <img width="22" height="22" src="<?php echo get_template_directory_uri(); ?>/assets/images/Mask-group.svg" alt="Hotline" />
                <span>Hotline</span>
            </a>
        </div>
    </div>

    <div class="item">
        <div class="item-inner">
            <a href="<?php echo get_theme_mod('zalo_link', 'https://zalo.me/0922222256'); ?>" title="Liên hệ Zalo" target="_blank">
                <img width="37" height="16" src="<?php echo get_template_directory_uri(); ?>/assets/images/Group-18811.svg" alt="Liên hệ Zalo" />
                <span>Liên hệ Zalo</span>
            </a>
        </div>
    </div>

    <div class="item">
        <div class="item-inner">
            <a href="<?php echo get_theme_mod('messenger_link', 'https://www.facebook.com/vandaibds1410'); ?>" title="Messenger" target="_blank">
                <img width="23" height="22" src="<?php echo get_template_directory_uri(); ?>/assets/images/Vector.svg" alt="Messenger" />
                <span>Messenger</span>
            </a>
        </div>
    </div>

    <div class="item">
        <div class="item-inner">
            <a href="<?php echo get_theme_mod('tiktok_link', 'https://www.tiktok.com/@thelinkcity.net'); ?>" title="Tiktok" target="_blank">
                <img width="23" height="22" src="<?php echo get_template_directory_uri(); ?>/assets/images/tiktok.svg" alt="Tiktok" />
                <span>Tiktok</span>
            </a>
        </div>
    </div>
</div>
<!-- ============================ END FIXED BUTTONS ============================ -->

<!-- JavaScript -->
<!-- Scripts are loaded via functions.php -->
<div id="active-fullpage"></div>

<?php wp_footer(); ?>
</body>

</html>