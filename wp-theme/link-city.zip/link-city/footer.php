<!-- ============================ FOOTER ============================ -->

<!-- First modal -->
<div class="modal-container" id="lepopup-form-13">
    <div class="modal-content lepopup-form-inner">
        <div class="lepopup-element lepopup-element-2">
            <form class="lepopup-form">
                <h2 class="lepopup-element-title" data-aos="fade-up" data-aos-duration="700">
                    ĐĂNG KÝ TÌM HIỂU <br />
                    THÔNG TIN DỰ ÁN
                </h2>

                <div class="lepopup-element-description" data-aos="fade-up" data-aos-duration="700">
                    Vui lòng để lại thông tin, nhân viên chúng tôi <br />
                    sẽ liên hệ lại với Quý khách sớm nhất có thể.
                </div>

                <div class="flex-box" style="gap: 15px; margin-top: 20px" data-aos="fade-up" data-aos-duration="800">
                    <div class="lepopup-input">
                        <input type="text"
                               name="lepopup-7"
                               class="lepopup-ta-left"
                               placeholder="Tên của bạn"
                               autocomplete="off"
                               value=""
                               aria-label="Name Field" />
                    </div>
                    <div class="lepopup-input">
                        <input type="text"
                               name="lepopup-6"
                               class="lepopup-ta-left"
                               placeholder="Số điện thoại"
                               autocomplete="tel"
                               value=""
                               aria-label="Phone Field" />
                    </div>
                </div>

                <div class="lepopup-input" style="margin-top: 15px" data-aos="fade-up" data-aos-duration="900">
                    <input type="email"
                           name="lepopup-18"
                           class="lepopup-ta-left"
                           placeholder="Email của bạn"
                           autocomplete="email"
                           data-default=""
                           value=""
                           aria-label="E-mail Field" />
                </div>
                
                <div class="lepopup-button-wrapper" data-aos="fade-up" data-aos-duration="1000">
                    <a class="lepopup-button lepopup-button-zoom-out"
                       href="#"
                       onclick="return lepopup_submit(this);">
                        GỬI THÔNG TIN
                    </a>
                </div>

                <div class="lepopup-close">
                    <span>×</span>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- // load home page  -->
<div class="load_home_page">
    <div class="mask">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>
    <svg class="draw-svg" xmlns="http://www.w3.org/2000/svg" version="1.2" viewBox="0 0 418 180" width="450" height="194">
        <path class="path-1" d="m20.2 166.4q-1.5-1-2.3-2.7-0.7-1.6-0.7-3.5 0-1.9 0.7-3.5 0.8-1.7 2.3-2.7 1.6-1 3.7-1 1.9 0 3.2 0.7 1.3 0.7 2 1.8 0.7 1.1 0.9 2.4h-2.2q-0.3-1.2-1.2-2-1-0.9-2.7-0.9-1.4 0-2.4 0.7-1 0.8-1.6 2-0.5 1.1-0.5 2.5 0 1.3 0.5 2.5 0.6 1.2 1.6 1.9 1 0.8 2.4 0.8 1.7 0 2.7-0.9 0.9-0.8 1.2-2h2.2q-0.2 1.3-0.9 2.4-0.7 1.1-2 1.8-1.3 0.7-3.2 0.7-2.1 0-3.7-1z"></path>
        <path class="path-1" fill-rule="evenodd" d="m33.9 166.7q-1.2-0.7-1.8-1.9-0.6-1.2-0.6-2.6 0-1.4 0.6-2.6 0.6-1.2 1.8-1.9 1.1-0.7 2.7-0.7 1.6 0 2.7 0.7 1.2 0.7 1.8 1.9 0.6 1.2 0.6 2.6 0 1.4-0.6 2.6-0.6 1.2-1.8 1.9-1.1 0.7-2.7 0.7-1.6 0-2.7-0.7zm1.3-10.9h-1.9l2.4-3.3h1.8l2.3 3.3h-1.8l-1.4-2zm2.9 9.3q0.7-0.5 1-1.2 0.3-0.8 0.3-1.7 0-0.9-0.3-1.7-0.3-0.8-1-1.2-0.6-0.5-1.5-0.5-0.9 0-1.6 0.5-0.6 0.4-1 1.2-0.3 0.8-0.3 1.7 0 0.9 0.3 1.7 0.4 0.7 1 1.2 0.7 0.5 1.6 0.5 0.9 0 1.5-0.5zm-2.5 6.2q-0.4-0.4-0.4-1 0-0.5 0.4-0.9 0.4-0.4 1-0.4 0.5 0 0.9 0.4 0.4 0.4 0.4 0.9 0 0.6-0.4 1-0.4 0.4-0.9 0.4-0.6 0-1-0.4z"></path>
        <!-- Add more SVG paths as needed -->
    </svg>
</div>

<!-- ============================ FOOTER CONTENT ============================ -->

<footer id="footer" class="footer">
    <div class="footer-content">
        <div class="container">
            <div class="footer-top">
                <div class="footer-info">
                    <div class="footer-logo">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.svg" alt="K-Home New City" />
                    </div>
                    <div class="footer-description">
                        <p>Dự án K-Home New City - Nơi an cư lý tưởng cho gia đình Việt</p>
                    </div>
                </div>
                
                <div class="footer-contact">
                    <h3>Thông tin liên hệ</h3>
                    <div class="contact-info">
                        <div class="contact-item">
                            <img width="22" height="22" src="<?php echo get_template_directory_uri(); ?>/assets/images/Mask-group.svg" alt="Hotline" />
                            <a href="tel:<?php echo get_theme_mod('phone_number', '0937961212'); ?>" title="Hotline">
                                <?php echo get_theme_mod('phone_display', '09.222.222.56'); ?>
                            </a>
                        </div>
                        <div class="contact-item">
                            <img width="22" height="22" src="<?php echo get_template_directory_uri(); ?>/assets/images/Envelope.svg" alt="Email" />
                            <a href="mailto:<?php echo get_theme_mod('email_address', 'info@kimoanhgroup.vn'); ?>">
                                <?php echo get_theme_mod('email_address', 'info@kimoanhgroup.vn'); ?>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="footer-social">
                    <h3>Theo dõi chúng tôi</h3>
                    <div class="social-links">
                        <a href="<?php echo get_theme_mod('zalo_link', 'https://zalo.me/3783004274492024975'); ?>" title="Liên hệ Zalo" target="_blank">
                            <img width="37" height="16" src="<?php echo get_template_directory_uri(); ?>/assets/images/Group-18811.svg" alt="Liên hệ Zalo" />
                        </a>
                        <a href="<?php echo get_theme_mod('messenger_link', 'https://www.facebook.com/khomenewcityofficial'); ?>" title="Messenger" target="_blank">
                            <img width="23" height="22" src="<?php echo get_template_directory_uri(); ?>/assets/images/Vector.svg" alt="Messenger" />
                        </a>
                        <a href="<?php echo get_theme_mod('tiktok_link', 'https://www.tiktok.com/@thelinkcity.net'); ?>" title="Tiktok" target="_blank">
                            <img width="23" height="22" src="<?php echo get_template_directory_uri(); ?>/assets/images/tiktok.svg" alt="Tiktok" />
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="copyright">
                    <p><?php echo get_theme_mod('copyright_text', '© 2024 K-Home New City. All rights reserved.'); ?></p>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- ============================ END FOOTER ============================ -->

<!-- JavaScript -->
<!-- Scripts are loaded via functions.php -->
<div id="active-fullpage"></div>

<?php wp_footer(); ?>
</body>
</html>