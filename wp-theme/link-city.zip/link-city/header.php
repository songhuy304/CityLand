<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- CSS files are loaded via functions.php -->
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <div class="wrapper" id="wrapper">
        <!-- ============================ HEADER ============================ -->
        
        <header id="header">
            <div class="header-wrapper">
                <div id="masthead" class="header-main">
                    <div class="header-left">
                        <ul class="header-nav header-nav-main nav nav-left nav-uppercase">
                            <li class="nav-icon has-icon">
                                <a href="#" class="header-nav-icon" aria-label="Menu">
                                    <span class="hamburger">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </span>
                                    <span class="menu-text hide-for-small">MENU</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    
                    <div class="logo-wrapper">
                        <a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/Layer_1.svg"
                                 class="header_logo header-logo"
                                 alt="<?php bloginfo('name'); ?>" />
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-light.svg"
                                 class="header_logo header-logo-dark"
                                 alt="<?php bloginfo('name'); ?>" />
                        </a>
                    </div>

                    <div class="flex-col hide-for-medium flex-right">
                        <ul class="header-nav header-nav-main nav nav-right nav-uppercase">
                            <li class="header-search header-search-lightbox has-icon">
                                <a href="#search-lightbox"
                                   aria-label="Search"
                                   data-open="#search-lightbox"
                                   data-focus="input.search-field"
                                   class="is-small"
                                   data-target="#search-lightbox">
                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20.7055 20L16.9712 16.3056M19.6385 9.97222C19.6385 14.9274 15.5781 18.9444 10.5692 18.9444C5.56044 18.9444 1.5 14.9274 1.5 9.97222C1.5 5.017 5.56044 1 10.5692 1C15.5781 1 19.6385 5.017 19.6385 9.97222Z"
                                              stroke="white" stroke-width="1.5" stroke-linecap="square"></path>
                                    </svg>
                                </a>
                            </li>
                            
                            <li class="html header-button-1">
                                <a href="tel:<?php echo get_theme_mod('phone_number', '0937961212'); ?>" target="_self">
                                    <span class="icon">
                                        <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                  d="M43.63 39.3891C39.3223 44.9042 32.6101 48.4499 25.0698 48.4499C12.0706 48.4499 1.53271 37.912 1.53271 24.9128C1.53271 11.9136 12.0706 1.37573 25.0698 1.37573C33.0542 1.37573 40.1101 5.35141 44.3658 11.4312L45.5987 11.4677C41.2145 4.78728 33.6573 0.375732 25.0698 0.375732C11.5183 0.375732 0.532715 11.3614 0.532715 24.9128C0.532715 38.4643 11.5183 49.4499 25.0698 49.4499C33.1911 49.4499 40.391 45.5043 44.8569 39.4255L43.63 39.3891Z"
                                                  fill="white"></path>
                                        </svg>
                                        <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M21.5149 14.8525L17.1239 12.9706C16.8946 12.8719 16.6443 12.8322 16.3957 12.855C16.1472 12.8779 15.9083 12.9626 15.7009 13.1014L13.3531 14.6664C11.9182 13.9685 10.7568 12.8123 10.0526 11.3805L10.0528 11.3803L11.6123 8.99734C11.748 8.79047 11.8304 8.55318 11.852 8.30669C11.8736 8.0602 11.8338 7.8122 11.7361 7.58487L9.85248 3.19006C9.72426 2.89174 9.50286 2.64298 9.22143 2.48103C8.94 2.31907 8.61367 2.25263 8.29132 2.29166C7.02463 2.45452 5.86056 3.07296 5.01656 4.03144C4.17256 4.98992 3.70637 6.22289 3.70508 7.5C3.70508 14.944 9.76111 21 17.2051 21C18.4822 20.9987 19.7152 20.5325 20.6737 19.6885C21.6321 18.8445 22.2506 17.6804 22.4134 16.4137C22.4523 16.0913 22.3858 15.765 22.2239 15.4836C22.0619 15.2022 21.8132 14.9808 21.5149 14.8525Z"
                                                  fill="#F26A23"></path>
                                        </svg>
                                    </span>
                                    <span class="hotline ts-04"><?php echo get_theme_mod('phone_display', '09.222.222.56'); ?></span>
                                </a>
                            </li>
                            
                            <li class="header-divider"></li>
                            
                            <li class="html header-button-2">
                                <a href="<?php echo get_theme_mod('google_map_link', 'https://maps.app.goo.gl/nHH9dRpE6nq9rAGz9'); ?>" target="_blank">
                                    <span class="icon">
                                        <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                  d="M43.63 39.3891C39.3223 44.9042 32.6101 48.4499 25.0698 48.4499C12.0706 48.4499 1.53271 37.912 1.53271 24.9128C1.53271 11.9136 12.0706 1.37573 25.0698 1.37573C33.0542 1.37573 40.1101 5.35141 44.3658 11.4312L45.5987 11.4677C41.2145 4.78728 33.6573 0.375732 25.0698 0.375732C11.5183 0.375732 0.532715 11.3614 0.532715 24.9128C0.532715 38.4643 11.5183 49.4499 25.0698 49.4499C33.1911 49.4499 40.391 45.5043 44.8569 39.4255L43.63 39.3891Z"
                                                  fill="white"></path>
                                        </svg>
                                        <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12.5 0C7.806 0 4 3.806 4 8.5C4 13.194 12.5 24 12.5 24C12.5 24 21 13.194 21 8.5C21 3.806 17.194 0 12.5 0ZM12.5 11.5C11.119 11.5 10 10.381 10 9C10 7.619 11.119 6.5 12.5 6.5C13.881 6.5 15 7.619 15 9C15 10.381 13.881 11.5 12.5 11.5Z"
                                                  fill="#F26A23"></path>
                                        </svg>
                                    </span>
                                    <span class="map ts-04">Bản đồ</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- ============================ MAIN MENU ============================ -->
        
        <div id="nk-main-menu" class="flex-box flex-col jus-center rocket-lazyload lazyloaded"
             style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/images/header-bg-min.jpg');"
             data-ll-status="loaded">
            <div class="main-menu-inner">
                <div class="container">
                    <div class="flex-box flex-col jus-center al-center">
                        <div class="menu-wrapper">
                            <nav id="menu-main" class="main-menu">
                                <ul>
                                    <li><a href="#trang-chu">Trang chủ</a></li>
                                    <li><a href="#thiet-ke">Thiết kế</a></li>
                                    <li><a href="#tong-quan">Tổng quan</a></li>
                                    <li><a href="#ngoai-khu">Ngoại khu</a></li>
                                    <li><a href="#tien-do">Tiến độ</a></li>
                                    <li><a href="#lien-he">Liên hệ</a></li>
                                </ul>
                            </nav>
                            
                            <form role="search" method="get" class="search-form" action="<?php echo home_url('/'); ?>">
                                <input type="search" class="search-field" placeholder="Tìm kiếm..." value="" name="s" />
                                <button type="submit" class="search-submit">
                                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M20.7055 20L16.9712 16.3056M19.6385 9.97222C19.6385 14.9274 15.5781 18.9444 10.5692 18.9444C5.56044 18.9444 1.5 14.9274 1.5 9.97222C1.5 5.017 5.56044 1 10.5692 1C15.5781 1 19.6385 5.017 19.6385 9.97222Z"
                                              stroke="white" stroke-width="1.5" stroke-linecap="square"></path>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- ============================ END HEADER ============================ -->